package com.sht.smartlock.model;

/**
 * Created by Administrator on 2015/8/28.
 */
public class User {
    private String title;
    private String billnum;

    public String getBillnum() {
        return billnum;
    }

    public void setBillnum(String billnum) {
        this.billnum = billnum;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

}

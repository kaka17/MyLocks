package com.sht.smartlock.phone.ui.videomeeting;
public class ECGlobalConstants {



	public static final String REASON = "com.ccp.phone.reason";
	public static final String CONFNO = "com.ccp.phone.interphone.confNo";
	public static final String CLOOPEN_REASON = "com.ccp.phone.cloopenreason";


	
	/**视频会议*/
	public static final String CONFERENCE_ID = "com.ccp.phone.videoconf.conferenceId";
	
	public static final String IS_AUTO_JOIN = "isAutoJoin";
	public static final String VOICE_MOD = "voiceMod";
	public static final String AUTO_DELETE = "autoDelete";
	public static final String IS_AUTO_CLOSE = "isAutoClose";
	public static final String CHATROOM_NAME = "ChatroomName";
	public static final String CHATROOM_PWD = "ChatroomPwd";
	public static final String CHATROOM_CREATOR = "ChatroomCreator";
	
	public static final String INTENT_VIDEO_CONFERENCE_DISMISS  = "com.voice.demo.INTENT_VIDEO_CONFERENCE_DISMISS";


}

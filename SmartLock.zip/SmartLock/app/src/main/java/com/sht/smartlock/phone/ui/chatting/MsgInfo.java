package com.sht.smartlock.phone.ui.chatting;

/**
 * com.yuntongxun.ecdemo.ui.chatting in ECDemo_Android
 * Created by Jorstin on 2015/6/18.
 */
public class MsgInfo {

}

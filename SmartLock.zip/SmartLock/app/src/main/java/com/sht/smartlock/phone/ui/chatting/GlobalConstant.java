package com.sht.smartlock.phone.ui.chatting;

public class GlobalConstant {
	
	
	public static final int ACTIVITY_FOR_RESULT_VIDEORECORD=0x9;

}

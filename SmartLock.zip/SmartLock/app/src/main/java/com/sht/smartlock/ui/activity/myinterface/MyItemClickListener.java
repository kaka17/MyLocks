package com.sht.smartlock.ui.activity.myinterface;

import android.view.View;

public interface MyItemClickListener {
	public void onItemClick(View view, int postion);
}

package com.sht.smartlock.ui.activity.myinterface;

import android.view.View;

public interface ListItemClickHelp {
	void onClick(View item, View widget, int position, int which);
}

package com.sht.smartlock.ui.activity.myinterface;

import android.view.View;

public interface MyItemLongClickListener {
	public void onItemLongClick(View view, int postion);
}

package com.sht.smartlock.api.base;

/**
 * Created by Administrator on 2015/8/28.
 */
public class test {
    int a;
}

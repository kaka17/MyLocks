package com.sht.smartlock.phone.common.utils;

import java.util.HashMap;

/**
 * com.yuntongxun.ecdemo.common.utils in ECDemo_Android
 * Created by Jorstin on 2015/3/21.
 */
public class DialNumberMap {
    public static HashMap<Character, Integer> numberMap = new HashMap<Character, Integer>();
    static {
        numberMap.put('a', 2);
        numberMap.put('b', 2);
        numberMap.put('c', 2);
        numberMap.put('d', 3);
        numberMap.put('e', 3);
        numberMap.put('f', 3);
        numberMap.put('g', 4);
        numberMap.put('h', 4);
        numberMap.put('i', 4);
        numberMap.put('j', 5);
        numberMap.put('k', 5);
        numberMap.put('l', 5);
        numberMap.put('m', 6);
        numberMap.put('n', 6);
        numberMap.put('o', 6);
        numberMap.put('p', 7);
        numberMap.put('q', 7);
        numberMap.put('r', 7);
        numberMap.put('s', 7);
        numberMap.put('t', 8);
        numberMap.put('u', 8);
        numberMap.put('v', 8);
        numberMap.put('w', 9);
        numberMap.put('x', 9);
        numberMap.put('y', 9);
        numberMap.put('z', 9);

        numberMap.put('A', 2);
        numberMap.put('B', 2);
        numberMap.put('C', 2);
        numberMap.put('D', 3);
        numberMap.put('E', 3);
        numberMap.put('F', 3);
        numberMap.put('G', 4);
        numberMap.put('H', 4);
        numberMap.put('I', 4);
        numberMap.put('J', 5);
        numberMap.put('K', 5);
        numberMap.put('L', 5);
        numberMap.put('M', 6);
        numberMap.put('N', 6);
        numberMap.put('O', 6);
        numberMap.put('P', 7);
        numberMap.put('Q', 7);
        numberMap.put('R', 7);
        numberMap.put('S', 7);
        numberMap.put('T', 8);
        numberMap.put('U', 8);
        numberMap.put('V', 8);
        numberMap.put('W', 9);
        numberMap.put('X', 9);
        numberMap.put('Y', 9);
        numberMap.put('Z', 9);


        numberMap.put('0', 0);
        numberMap.put('1', 1);
        numberMap.put('2', 2);
        numberMap.put('3', 3);
        numberMap.put('4', 4);
        numberMap.put('5', 5);
        numberMap.put('6', 6);
        numberMap.put('7', 7);
        numberMap.put('8', 8);
        numberMap.put('9', 9);
    }
}

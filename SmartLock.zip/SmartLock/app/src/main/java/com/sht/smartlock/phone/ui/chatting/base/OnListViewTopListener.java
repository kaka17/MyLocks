package com.sht.smartlock.phone.ui.chatting.base;
public abstract interface OnListViewTopListener
{
  public abstract boolean getIsListViewToTop();
}
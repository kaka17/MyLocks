package com.sht.smartlock.model;

import java.io.Serializable;

/**
 * Created by chenjl on 2015/6/1.
 */
public class BaseModel implements Serializable {

}

package com.sht.smartlock.phone.ui.chatting.base;
public abstract interface OnRefreshAdapterDataListener
{
  public abstract void refreshData();
}
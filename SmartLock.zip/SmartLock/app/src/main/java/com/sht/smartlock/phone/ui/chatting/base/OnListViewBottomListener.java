package com.sht.smartlock.phone.ui.chatting.base;
public abstract interface OnListViewBottomListener
{
  public abstract boolean getIsListViewToBottom();
}
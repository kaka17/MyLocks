	package com.sht.smartlock.ui.activity.chatlocation;
	
	/**
	 * @author kaiser
	 * @date 2015-10-01
	 * @version 1.0
	 * @desc desc 公共常量
	 * 
	 */
	public class Common {
	
		public static final String LOCATION = "location";
		public static final String LOCATION_ACTION = "locationAction";
		public static final String LOCATION_ACTION_BYPOWER = "locationAction_bypower";
		public static final String LOCATION_TEST = "locationTEST";
	}

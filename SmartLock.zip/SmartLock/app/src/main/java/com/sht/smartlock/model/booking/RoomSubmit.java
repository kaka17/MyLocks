package com.sht.smartlock.model.booking;

/**
 * Created by Administrator on 2016/11/25.
 */
public class RoomSubmit {
    private String code;
    private String msg;
    private String book_id;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getBook_id() {
        return book_id;
    }

    public void setBook_id(String book_id) {
        this.book_id = book_id;
    }
}
